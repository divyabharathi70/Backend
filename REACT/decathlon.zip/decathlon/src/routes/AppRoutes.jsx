import React from 'react'
import NavBar from '../components/NavBar'

const AppRoutes = () => {
  return (
    <>
    <NavBar/>
    </>
  )
}

export default AppRoutes
